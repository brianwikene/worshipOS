<script>
  import ConnectionsHeader from '$lib/components/connections/ConnectionsHeader.svelte';
</script>

<ConnectionsHeader />

<div class="max-w-[1200px] mx-auto px-4 pb-12">
  <slot />
</div>
