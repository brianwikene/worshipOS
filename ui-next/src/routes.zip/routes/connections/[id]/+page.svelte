<script lang="ts">
	import {
		ArrowLeft,
		Briefcase,
		Calendar,
		CircleAlert,
		Clock,
		Eye,
		Heart,
		House,
		Info,
		Lock,
		Mail,
		MapPin,
		Phone,
		Shield,
		Star,
		Users
	} from '@lucide/svelte';

	import type { ActionData, PageData } from './$types';

	// Import your Drawers
	import AddCareNoteDrawer from './AddCareNoteDrawer.svelte';
	import ConnectFamilyDrawer from './ConnectFamilyDrawer.svelte';
	import EditCapabilityDrawer from './EditCapabilityDrawer.svelte';
	import EditHouseholdDrawer from './EditHouseholdDrawer.svelte';
	import EditProfileDrawer from './EditProfileDrawer.svelte';
	import EditTeamsDrawer from './EditTeamsDrawer.svelte';
	import ManageAddressesDrawer from './ManageAddressesDrawer.svelte';
	// <--- NEW IMPORT

	let { data, form } = $props<{ data: PageData; form: ActionData }>();

	// 1. Reactive Data Access
	let person = $derived(data.person);
	let careNotes = $derived(data.careNotes);
	let allFamilies = $derived(data.allFamilies);
	let allTeams = $derived(data.allTeams);

	// 2. Safe Proxy for Relations (handles 'any' typing issues)
	let p = $derived(person as any);

	// 3. Derived Helpers
	let familyMembers = $derived(p.family?.members?.filter((m: any) => m.id !== p.id) || []);

	// 4. UI State
	let isCareRevealed = $state(false);
	let isEditProfileOpen = $state(false);
	let isConnectFamilyOpen = $state(false);
	let isEditHouseholdOpen = $state(false);
	let isEditCapabilitiesOpen = $state(false);
	let isEditTeamsOpen = $state(false);
	let isAddCareNoteOpen = $state(false);
	let isManageAddressesOpen = $state(false); // <--- NEW STATE

	function getComfortLabel(rating: number | null) {
		if (!rating) return 'Unrated';
		if (rating <= 2) return 'Learning';
		if (rating === 3) return 'Comfortable';
		return 'Leading';
	}

	// --- TEAM GROUPING LOGIC ---
	type GroupedTeam = {
		team: { name: string; [key: string]: any };
		roles: string[];
	};

	let activeMemberships = $derived(
		(p.teamMemberships || []).filter((m: any) => m.status === 'active')
	);

	let groupedTeams = $derived(
		Object.values(
			activeMemberships.reduce(
				(acc: Record<string, GroupedTeam>, m: any) => {
					if (!acc[m.team.id]) {
						acc[m.team.id] = { team: m.team, roles: [] };
					}
					acc[m.team.id].roles.push(m.role || 'Member');
					return acc;
				},
				{} as Record<string, GroupedTeam>
			)
		).sort((a: any, b: any) => a.team.name.localeCompare(b.team.name)) as GroupedTeam[]
	);
</script>

<div class="min-h-screen bg-stone-50 pb-20">
	<div class="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
		<div class="mb-6 flex items-center justify-between">
			<a
				href="/connections"
				class="inline-flex items-center gap-2 text-sm text-stone-500 transition-colors hover:text-slate-900"
			>
				<ArrowLeft size={16} />
				Back to People
			</a>
			<div class="flex gap-2">
				<button
					onclick={() => (isEditProfileOpen = true)}
					class="rounded-md bg-slate-800 px-3 py-1.5 text-xs font-medium text-white shadow-sm transition-colors hover:bg-slate-700"
				>
					Edit Profile
				</button>
			</div>
		</div>

		<div class="grid grid-cols-1 gap-8 lg:grid-cols-3">
			<div class="space-y-6">
				<div class="rounded-xl border border-stone-200 bg-white p-6 text-center shadow-sm">
					<div
						class="mx-auto mb-4 flex h-24 w-24 items-center justify-center overflow-hidden rounded-full bg-stone-100 text-2xl font-bold text-stone-500"
					>
						{#if p.avatar_url}
							<img
								src={p.avatar_url}
								alt={p.first_name ?? 'Person'}
								class="h-full w-full object-cover"
							/>
						{:else}
							{p.first_name?.[0] ?? '?'}{p.last_name?.[0] ?? ''}
						{/if}
					</div>
					<h1 class="text-2xl font-bold text-slate-900">{p.first_name} {p.last_name}</h1>
					{#if p.occupation}
						<p class="mt-1 flex items-center justify-center gap-1 text-sm text-stone-500">
							<Briefcase size={12} />
							{p.occupation}
						</p>
					{/if}

					<div class="mt-6 space-y-3 text-left">
						{#if p.email}
							<div class="flex items-center gap-3 text-sm text-stone-600">
								<Mail size={16} class="text-stone-400" />
								<a href="mailto:{p.email}" class="transition-colors hover:text-slate-900"
									>{p.email}</a
								>
							</div>
						{/if}
						{#if p.phone}
							<div class="flex items-center gap-3 text-sm text-stone-600">
								<Phone size={16} class="text-stone-400" />
								<span>{p.phone}</span>
							</div>
						{/if}
					</div>
				</div>

				<div class="rounded-xl border border-stone-200 bg-white p-6 shadow-sm">
					<div class="mb-5 flex items-start justify-between">
						<div>
							<h3
								class="flex items-center gap-2 text-xs font-bold tracking-wider text-stone-400 uppercase"
							>
								<House class="h-3 w-3" /> Household

								<div class="group relative ml-1 inline-flex cursor-help items-center">
									<Info size={12} class="text-stone-300 transition-colors hover:text-stone-500" />
									<div
										class="pointer-events-none absolute bottom-full left-1/2 z-50 mb-2 w-64 -translate-x-1/2 opacity-0 transition-opacity duration-200 group-hover:opacity-100"
									>
										<div
											class="rounded-lg bg-slate-800 p-3 text-left text-xs leading-relaxed font-normal text-stone-200 normal-case shadow-xl ring-1 ring-white/10"
										>
											<p>Households group people who share an address or contact details.</p>
											<p class="mt-2 text-stone-400">
												This does not imply guardianship or decision-making authority.
											</p>
										</div>
										<div
											class="absolute -bottom-1 left-1/2 h-2 w-2 -translate-x-1/2 rotate-45 bg-slate-800"
										></div>
									</div>
								</div>
							</h3>
						</div>

						{#if p.family}
							<button
								onclick={() => (isEditHouseholdOpen = true)}
								class="rounded-md border border-stone-200 bg-stone-50 px-3 py-1 text-xs font-bold text-stone-600 shadow-sm transition-all hover:border-stone-300 hover:bg-white hover:text-slate-900"
							>
								Edit Family
							</button>
						{/if}
					</div>

					{#if p.family}
						<div class="mb-5 border-b border-stone-100 pb-5">
							<div class="text-sm font-bold text-slate-900">{p.family.name}</div>

							<div class="mt-4 flex items-start gap-3">
								<div
									class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-stone-50 text-stone-400"
								>
									<MapPin size={16} />
								</div>

								<div class="flex-1 pt-0.5">
									{#if p.family.addresses && p.family.addresses.length > 0}
										{@const activeAddresses = p.family.addresses.filter(
											(a: any) => !a.end_date || new Date(a.end_date) > new Date()
										)}
										{@const displayList =
											activeAddresses.length > 0 ? activeAddresses : p.family.addresses}
										{@const primary = displayList.find((a: any) => a.is_primary) || displayList[0]}

										<div class="text-sm text-slate-700">
											{primary.street}
										</div>
										<div class="text-xs text-stone-500">
											{primary.city}, {primary.state}
											{primary.zip}
										</div>

										{#if primary.type !== 'home' || primary.is_primary}
											<div class="mt-1.5 flex gap-2">
												{#if primary.is_primary}
													<span
														class="inline-flex items-center rounded bg-sky-100 px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-sky-800 uppercase"
													>
														Primary
													</span>
												{/if}
												{#if primary.type !== 'home'}
													<span
														class="inline-flex items-center rounded bg-stone-100 px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-stone-600 uppercase"
													>
														{primary.type}
													</span>
												{/if}
											</div>
										{/if}
									{:else if p.family.address_city}
										<div class="text-sm text-stone-500">
											{p.family.address_street || 'Street not listed'}
										</div>
										<div class="text-xs text-stone-400">
											{p.family.address_city}, {p.family.address_state}
											{p.family.address_zip}
										</div>
									{:else}
										<div class="text-xs text-stone-400 italic">No address listed.</div>
									{/if}

									<button
										onclick={() => (isManageAddressesOpen = true)}
										class="mt-2 text-[10px] font-bold tracking-wide text-blue-600 uppercase hover:text-blue-800 hover:underline"
									>
										Manage Addresses
									</button>
								</div>
							</div>
						</div>

						<div class="space-y-2">
							{#each familyMembers as member}
								<a
									href="/connections/{member.id}"
									class="-mx-2 flex items-center justify-between rounded-lg p-2 transition-colors hover:bg-stone-50"
								>
									<div class="flex items-center gap-3">
										<div
											class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-stone-100 text-xs font-bold text-stone-600"
										>
											{member.first_name?.[0] ?? '?'}
										</div>
										<div>
											<div class="flex items-center gap-1.5">
												<span class="text-sm text-stone-700">
													{member.first_name}
													<span class="font-semibold text-slate-900">{member.last_name}</span>
												</span>
												{#if member.is_household_primary}
													<Star size={10} class="fill-amber-400 text-amber-400" />
												{/if}
											</div>
											{#if member.household_role}
												<div class="text-[10px] font-medium tracking-wide text-stone-400 uppercase">
													{member.household_role}
												</div>
											{/if}
										</div>
									</div>
								</a>
							{/each}
						</div>
					{:else}
						<div class="py-4 text-center">
							<p class="text-xs text-stone-400 italic">Not connected to a household.</p>
							<button
								onclick={() => (isConnectFamilyOpen = true)}
								class="mt-2 text-xs font-medium text-slate-600 underline underline-offset-2 hover:text-slate-900"
							>
								Connect Household
							</button>
						</div>
					{/if}
				</div>

				{#if p.relationships && p.relationships.length > 0}
					<div class="rounded-xl border border-stone-200 bg-white p-6 shadow-sm">
						<h3
							class="mb-4 flex items-center gap-2 text-xs font-bold tracking-wider text-stone-400 uppercase"
						>
							<Heart size={12} /> Connected Lives
						</h3>
						<div class="space-y-2">
							{#each p.relationships as rel}
								<a
									href="/connections/{rel.relatedPerson.id}"
									class="-mx-2 flex items-center justify-between rounded-lg p-2 transition-colors hover:bg-stone-50"
								>
									<span class="text-sm text-stone-700">
										{rel.relatedPerson.first_name}
										{rel.relatedPerson.last_name}
									</span>
									<span
										class="rounded-full border border-stone-200 bg-stone-100 px-2 py-1 text-[10px] text-stone-600"
									>
										{rel.type}
									</span>
								</a>
							{/each}
						</div>
					</div>
				{/if}
			</div>

			<div class="space-y-6 lg:col-span-2">
				<div
					class="relative overflow-hidden rounded-xl border border-sky-100 bg-gradient-to-br from-sky-50 to-white p-6 shadow-sm"
				>
					<div class="mb-3 flex items-center gap-2">
						{#if p.capacity_note}
							<Shield size={18} class="text-sky-600" />
							<h3 class="text-sm font-bold tracking-wide text-sky-900 uppercase">Current Season</h3>
						{:else}
							<Calendar size={18} class="text-sky-400" />
							<h3 class="text-sm font-bold tracking-wide text-sky-800 uppercase">
								Current Context
							</h3>
						{/if}
					</div>

					{#if p.bio}
						<p class="mb-4 leading-relaxed text-stone-700">{p.bio}</p>
					{:else}
						<p class="mb-4 text-sm text-stone-400 italic">No bio added yet.</p>
					{/if}

					{#if p.capacity_note}
						<div class="mt-4 rounded-lg border border-sky-200 bg-white/80 p-4 backdrop-blur-sm">
							<p class="text-xs font-semibold tracking-wider text-sky-800 uppercase opacity-70">
								Capacity Note
							</p>
							<p class="mt-1 text-sm font-medium text-slate-900 italic">
								"{p.capacity_note}"
							</p>
						</div>
					{/if}
				</div>

				<div
					class="rounded-xl border border-emerald-100 bg-emerald-50/30 p-6 shadow-sm transition-all hover:border-emerald-200"
				>
					<div class="mb-6 flex items-center justify-between">
						<h3 class="flex items-center gap-2 text-base font-bold text-emerald-900">
							<Users size={16} class="text-emerald-600" />
							Teams & Serving
						</h3>
						<button
							onclick={() => (isEditTeamsOpen = true)}
							class="rounded-md border border-emerald-200 bg-white px-3 py-1 text-xs font-bold text-emerald-700 shadow-sm transition-all hover:border-emerald-300 hover:text-emerald-900"
						>
							Manage
						</button>
					</div>

					{#if groupedTeams.length > 0}
						<div class="space-y-4">
							{#each groupedTeams as group}
								<div
									class="rounded-lg border border-emerald-100 bg-white/80 p-3 shadow-sm backdrop-blur-sm"
								>
									<div class="flex items-start gap-3">
										<div
											class="flex h-10 w-10 shrink-0 items-center justify-center rounded border border-emerald-100 bg-emerald-50 font-bold text-emerald-600"
										>
											{group.team.name[0]}
										</div>

										<div class="flex-1">
											<div class="text-sm font-bold text-slate-900">{group.team.name}</div>
											<div class="mt-2 flex flex-wrap gap-2">
												{#each group.roles as role}
													<span
														class="inline-flex items-center rounded-md border border-stone-200 bg-white px-2 py-1 text-xs font-medium text-stone-600"
													>
														{role}
													</span>
												{/each}
											</div>
										</div>
									</div>
								</div>
							{/each}
						</div>
					{:else}
						<div class="rounded-lg border border-dashed border-emerald-200/50 p-4 text-center">
							<p class="text-sm text-emerald-800/60 italic">
								No active serving commitments this season.
							</p>
						</div>
					{/if}
				</div>

				<div class="rounded-xl border border-slate-200 bg-slate-50/50 p-6 shadow-sm">
					<div class="mb-6 flex items-center justify-between">
						<h3 class="flex items-center gap-2 text-base font-bold text-slate-700">
							<Briefcase size={16} class="text-slate-500" />
							Capabilities
						</h3>
						<button
							onclick={() => (isEditCapabilitiesOpen = true)}
							class="rounded-md border border-slate-200 bg-white px-3 py-1 text-xs font-bold text-slate-600 shadow-sm transition-all hover:border-slate-300 hover:text-slate-900"
						>
							Edit
						</button>
					</div>

					{#if p.capabilities && p.capabilities.length > 0}
						<div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
							{#each p.capabilities as cap}
								<div
									class="flex flex-col gap-2 rounded-lg border border-slate-200 bg-white p-3 shadow-sm"
								>
									<div class="flex items-start justify-between">
										<span class="text-sm font-bold text-slate-800">{cap.capability}</span>
										<div class="flex gap-1" title="Comfort Level: {getComfortLabel(cap.rating)}">
											{#each Array(5) as _, i}
												<div
													class={`h-1.5 w-1.5 rounded-full ${
														i < (cap.rating || 0) ? 'bg-slate-800' : 'bg-slate-100'
													}`}
												></div>
											{/each}
										</div>
									</div>
									{#if cap.notes}
										<p class="text-xs text-slate-500 italic">"{cap.notes}"</p>
									{/if}
								</div>
							{/each}
						</div>
					{:else}
						<div class="rounded-lg border-2 border-dashed border-slate-200 py-6 text-center">
							<p class="text-sm text-slate-400">Specific skills and gifts have not been noted.</p>
							<button
								onclick={() => (isEditCapabilitiesOpen = true)}
								class="mt-2 text-xs font-medium text-slate-600 underline underline-offset-2 hover:text-slate-900"
							>
								Add Capability
							</button>
						</div>
					{/if}
				</div>

				<div
					class="rounded-xl border border-amber-200 bg-amber-50/50 p-6 transition-all duration-300"
				>
					<div class="mb-4">
						<div class="flex items-center justify-between">
							<h3
								class="flex items-center gap-2 text-xs font-bold tracking-wider text-amber-900 uppercase"
							>
								<CircleAlert size={12} /> Care Notes
							</h3>

							{#if isCareRevealed}
								<button
									onclick={() => (isAddCareNoteOpen = true)}
									class="text-xs font-bold text-amber-700/60 hover:text-amber-900"
								>
									+ Add Note
								</button>
							{/if}
						</div>
						<p class="mt-1 text-xs text-amber-700/70 italic">
							Private pastoral notes. Access is restricted.
						</p>
					</div>

					{#if !isCareRevealed}
						<div
							class="flex flex-col items-center justify-center rounded-lg border border-amber-100 bg-white/60 py-8 text-center backdrop-blur-sm"
						>
							<div class="mb-3 rounded-full bg-amber-100 p-2 text-amber-600">
								<Lock size={20} />
							</div>
							<h4 class="text-sm font-semibold text-amber-900">Content Hidden</h4>
							<p class="mb-4 max-w-[250px] text-xs text-amber-700/70">
								These notes are hidden to protect privacy on shared screens.
							</p>
							<button
								onclick={() => (isCareRevealed = true)}
								class="inline-flex items-center gap-2 rounded-md bg-amber-100 px-4 py-2 text-xs font-bold text-amber-800 transition-colors hover:bg-amber-200"
							>
								<Eye size={14} />
								View Notes
							</button>
						</div>
					{:else if careNotes.length > 0}
						<div class="animate-in fade-in slide-in-from-top-2 space-y-4 duration-300">
							{#each careNotes as note}
								<div
									class="relative rounded-lg border border-amber-100 bg-white p-4 text-sm shadow-sm transition-shadow hover:shadow-md"
								>
									<p class="text-slate-800">{note.content}</p>
									<div class="mt-2 flex items-center gap-2 text-xs text-stone-400">
										<span class="rounded bg-amber-50 px-1.5 py-0.5 font-medium text-amber-700">
											{note.category || 'General'}
										</span>
										<span>•</span>
										<span class="flex items-center gap-1">
											<Clock size={10} />
											{note.created_at ? new Date(note.created_at).toLocaleDateString() : 'Unknown'}
										</span>
									</div>
								</div>
							{/each}

							<button
								onclick={() => (isCareRevealed = false)}
								class="mt-4 w-full text-center text-xs text-amber-700/50 hover:text-amber-900"
							>
								Hide Notes
							</button>
						</div>
					{:else}
						<div
							class="animate-in fade-in rounded-lg border border-dashed border-amber-200 py-8 text-center"
						>
							<p class="text-sm text-amber-900">No notes recorded yet.</p>
							<p class="mt-1 text-xs text-amber-700/60 italic">
								You have access, but this file is empty.
							</p>
							<button
								onclick={() => (isAddCareNoteOpen = true)}
								class="mt-3 text-xs font-bold text-amber-700 underline underline-offset-2 hover:text-amber-900"
							>
								Create first note
							</button>
						</div>
					{/if}
				</div>
			</div>
		</div>
	</div>
</div>

<EditProfileDrawer bind:open={isEditProfileOpen} person={p} {form} />
<ConnectFamilyDrawer bind:open={isConnectFamilyOpen} {allFamilies} />
<EditHouseholdDrawer bind:open={isEditHouseholdOpen} person={p} />
<EditCapabilityDrawer bind:open={isEditCapabilitiesOpen} person={p} />
<EditTeamsDrawer bind:open={isEditTeamsOpen} person={p} {allTeams} />
<AddCareNoteDrawer bind:open={isAddCareNoteOpen} />
<ManageAddressesDrawer bind:open={isManageAddressesOpen} person={p} />
