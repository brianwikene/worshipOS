import { db } from '$lib/server/db';
import { plans } from '$lib/server/db/schema';
import { error } from '@sveltejs/kit';
import { and, eq } from 'drizzle-orm';
import type { LayoutServerLoad } from './$types';

export const load: LayoutServerLoad = async ({ params, locals }) => {
	const { church } = locals;
	if (!church) error(404, 'Church not found');

	const { gathering_id, instance_id } = params;
	// Note: 'instance_id' is the param name because of the folder name [instance_id]
	// even though it refers to a Plan ID now.

	if (!gathering_id || !instance_id) {
		throw error(400, 'Missing route parameters');
	}

	// 1. Fetch the Plan (and include its Gathering parent)
	// We query the Plan first because it links to the Gathering.
	const planData = await db.query.plans.findFirst({
		where: and(
			eq(plans.id, instance_id),
			eq(plans.church_id, church.id),
			eq(plans.gathering_id, gathering_id) // Ensure it belongs to this gathering
		),
		with: {
			gathering: {
				with: {
					campus: true
				}
			}
		}
	});

	if (!planData) {
		throw error(404, 'Plan not found');
	}

	// 2. Return data
	// We return 'plan' and 'gathering' separately for convenience in the UI
	return {
		plan: planData,
		gathering: planData.gathering
	};
};
