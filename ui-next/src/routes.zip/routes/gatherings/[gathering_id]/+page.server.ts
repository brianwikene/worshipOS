import { db } from '$lib/server/db';
import { gatherings, plans } from '$lib/server/db/schema';
import { error, fail, redirect } from '@sveltejs/kit';
import { and, asc, eq } from 'drizzle-orm';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ params, url, locals }) => {
	const { church } = locals;
	if (!church) throw error(401, 'Unauthorized');

	const gathering = await db.query.gatherings.findFirst({
		where: and(eq(gatherings.id, params.gathering_id), eq(gatherings.church_id, church.id)),
		with: {
			plans: {
				with: {
					items: { columns: { id: true } }
				}
			},
			campus: true
		}
	});

	if (!gathering) throw error(404, 'Gathering not found');

	// --- SMART REDIRECT LOGIC ---
	// If there is only ONE plan, go straight to the order.
	const forceManage = url.searchParams.get('manage') === 'true';

	if (gathering.plans.length === 1 && !forceManage) {
		throw redirect(
			303,
			`/gatherings/${params.gathering_id}/plans/${gathering.plans[0].id}/order`
		);
	}

	return { gathering };
};

export const actions: Actions = {
	addPlan: async ({ request, params, locals }) => {
		const { church } = locals;
		if (!church) throw error(401, 'Unauthorized');

		const data = await request.formData();
		const title = (data.get('name') as string) || 'Sunday Gathering';

		await db.insert(plans).values({
			church_id: church.id,
			gathering_id: params.gathering_id,
			title: title
		});

		return { success: true };
	}
};
