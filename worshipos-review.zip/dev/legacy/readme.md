# Legacy API Archive (inactive)

This folder is preserved for reference only.

- It previously contained a Node/Express API + database migrations/seeds used for early prototyping.
- It is NOT part of the active runtime.
- Active app work happens under `ui/` (SvelteKit).

Safe to delete later once the new system is stable.
