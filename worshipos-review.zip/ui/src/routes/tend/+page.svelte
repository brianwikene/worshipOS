<script>
  import UnderDevelopment from '$lib/components/common/UnderDevelopment.svelte';
</script>

<UnderDevelopment featureName="Tend" />
